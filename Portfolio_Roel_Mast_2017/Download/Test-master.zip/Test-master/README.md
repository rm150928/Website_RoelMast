Number Wizard
